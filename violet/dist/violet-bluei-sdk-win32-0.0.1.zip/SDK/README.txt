===============================================================
Violet Blue I - README
===============================================================

Thanks for downloading the Violet Blue I SDK v0.0.1!

                         Introduction
    
The Violet Blue I can be defined as a virtual multimedia card
you can interact with using binary commands through the Violet
Terminal.

It supports:
- 10x20 font rendering
- 32-bit xRGB colors
- 4 audio channels to play PSG sounds
- Global audio pitch modulation
- 256-slot cache for 32-bit xRGB bitmaps
- Primitive shape rasterizer (rectangles, lines and ellipses)

                           Warning

Violet Blue I isn't finished yet. Specifications cited above won't
change but the behaviour of the terminal and the content of the SDK
could change at any time.

                    What the SDK contains

bin/
+ violet.exe    Violet Blue I Terminal
demos/
+ bouncing/     Bouncing demo
+ shapes/       Shapes demo
+ wireframe/    3D Wireframe cube demo
docs/
+ MANUAL.txt    User Manual for the Violet Blue I
include/
+ bluei.h       Basic Violet Blue I header for commands
Homepage        Shortcut for the Violet Blue I homepage
README.txt      This document

                         License

All files that ship with the Violet SDK are under the MIT License.
Copyright (c) Marc-Daniel DALEBA 2026