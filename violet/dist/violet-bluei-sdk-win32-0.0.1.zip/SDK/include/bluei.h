/*

	Violet Blue I SDK macros header.

FILE bluei.h
DATE 2026-08-10
AUTHOR Marc-Daniel DALEBA
DESC

Serialization Macros:
	pPut8(ptr, value)         : Writes an 8-bit unsigned integer into `ptr` and advances pointer.
	pPut16(ptr, value)        : Writes a 16-bit little-endian integer into `ptr` and advances pointer.
	pPut32(ptr, value)        : Writes a 32-bit little-endian integer into `ptr` and advances pointer.
	pPutBuf(ptr, len, buf)    : Copies `len` bytes from `buf` into `ptr` and advances pointer by `len`.
	pCMD_*(ptr, <args>)       : Emits a * command into `ptr` with the provided arguments

*/
#ifndef BLUE_I__H
#define BLUE_I__H

#define pPut8(p,x)                *p++=x&0xFF
#define pPut16(p,x)               *p++=x&0xFF;*p++=(x>>8)&0xFF
#define pPut32(p,x)               *p++=x&0xFF;*p++=(x>>8)&0xFF;*p++=(x>>16)&0xFF;*p++=(x>>24)&0xFF
#define pPutBuf(p,len,b)          do{memcpy((p),(b),(len));(p)+=(len);}while(0)
	
#define pCMD_NOP(p)               pPut8(p,0x00)
#define pCMD_ENV(p)               pPut8(p,0x01)
#define pCMD_SYNC(p)              pPut8(p,0x02)
#define pCMD_RESET(p)             pPut8(p,0x03)
#define pCMD_BITMID(p,i)          do{pPut8(p,0x04);pPut32(p,i);}while(0)
#define pCMD_LOADBITM(p,w,h,d)    do{pPut8(p,0x05);pPut16(p,w);pPut16(p,h);pPutBuf(p,w*h*4,d);}while(0)
#define pCMD_CLEAR(p)             pPut8(p,0x06)
#define pCMD_SETWIN(p,w,h)        do{pPut8(p,0x07);pPut16(p,w);pPut16(p,h);}while(0)
#define pCMD_SETSCALE(p,s)        do{pPut8(p,0x08);pPut8(p,s);}while(0)
#define pCMD_SETCOLOR(p,r,g,b,a)  do{pPut8(p,0x09);pPut8(p,b);pPut8(p,g);pPut8(p,r);pPut8(p,a);}while(0)
#define pCMD_SETPOS(p,x,y)        do{pPut8(p,0x0A);pPut16(p,x);pPut16(p,y);}while(0)
#define pCMD_SETVOL(p,v,i)        do{pPut8(p,0x0B);pPut16(p,v);pPut16(p,i);}while(0)

#define pCMD_DRAWLINE(p,x,y)      do{pPut8(p,0x10);pPut16(p,x);pPut16(p,y);}while(0)
#define pCMD_DRAWRECT(p,w,h)      do{pPut8(p,0x11);pPut16(p,w);pPut16(p,h);}while(0)
#define pCMD_DRAWELLI(p,rx,ry)    do{pPut8(p,0x12);pPut16(p,rx);pPut16(p,ry);}while(0)
#define pCMD_DRAWBITM(p)          pPut8(p,0x13)
#define pCMD_DRAWTEXT(p,l,s)      do{pPut8(p,0x14);pPut16(p,0);pPut16(p,l);pPutBuf(p,l,s);}while(0)

#define pCMD_SETAUDIO(p,c,w,f)    do{pPut8(p,0x20);pPut8(p,c);pPut8(p,w);pPut16(p,f);}while(0)
#define pCMD_CHVOLUME(p,c,v)      do{pPut8(p,0x21);pPut8(p,c);pPut8(p,v);}while(0)

#define WAVE_NONE     0
#define WAVE_SQUARE   1
#define WAVE_TRIANGLE 2
#define WAVE_SAWTOOTH 3
#define WAVE_NOISE    4

#endif // BLUE_I__H