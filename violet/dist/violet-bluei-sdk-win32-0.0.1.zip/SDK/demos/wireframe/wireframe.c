/*

	Violet Blue I SDK demo
	
	Wireframe
	AUTHOR Marc-Daniel DALEBA
	DATE 2026-08-17
	DESC
		A program that draws a 3D wireframe cube.

*/
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <Windows.h>
#include <fcntl.h>
#include <io.h>
#include <bluei.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

unsigned char cmds[8000];
unsigned char* cmdp = cmds;
HWND hwnd;
float DPIscale;
int areaW, areaH;
int running = 0;

void getAreaSize(HWND hwnd, float DPIscale, int* w, int* h)
{
	RECT rc;
	GetClientRect(hwnd, &rc);
	*w = (int)((rc.right - rc.left) * DPIscale);
	*h = (int)((rc.bottom - rc.top) * DPIscale);
}

void cmd_reset(void)
{
	cmdp = cmds;
}

void cmd_push(void)
{
	fwrite(cmds, cmdp-cmds, 1, stdout);
	fflush(stdout);
}

int init(void)
{
	cmd_reset();
	pCMD_ENV(cmdp);
	cmd_push();
	
	Sleep(100);
	uintptr_t hwndValue;
	if (fread(&hwndValue, sizeof(hwndValue), 1, stdin) != 1) {
		return -1;
	}
	hwnd = (HWND)(uintptr_t)hwndValue;
	
	
	UINT dpi = GetDpiForWindow(hwnd);
	DPIscale = (float)dpi / 96.0f;
	
	getAreaSize(hwnd, DPIscale, &areaW, &areaH);
	return 0;
}

float vertices[] = {
	 1.000000f,  1.000000f, -1.000000f,
	 1.000000f, -1.000000f, -1.000000f,
	 1.000000f,  1.000000f,  1.000000f,
	 1.000000f, -1.000000f,  1.000000f,
	-1.000000f,  1.000000f, -1.000000f,
	-1.000000f, -1.000000f, -1.000000f,
	-1.000000f,  1.000000f,  1.000000f,
	-1.000000f, -1.000000f,  1.000000f,
};

int tris[] = {
	5, 3, 1,
	3, 8, 4,
	7, 6, 8,
	2, 8, 6,
	1, 4, 2,
	5, 2, 6,
	5, 7, 3,
	3, 7, 8,
	7, 5, 6,
	2, 4, 8,
	1, 3, 4,
	5, 1, 2,
};

float focal = 300.0f;

void project(float x, float y, float z, int* px, int* py)
{
	*px = (int)(focal * x / (z + 0.0001f)) + areaW/2;
	*py = (int)(focal * y / (z + 0.0001f)) + areaH/2;
}

void rotY(float* x, float* y, float* z, float angle)
{
	float rad = angle * (M_PI / 180.0f);
	float cosA = cosf(rad);
	float sinA = sinf(rad);
	
	float px = *x;
	float pz = *z;
	
	*x =  px * cosA + pz * sinA;
	*z = -px * sinA + pz * cosA;
}

void rotX(float* x, float* y, float* z, float angle)
{
	float rad = angle * (M_PI / 180.0f);
	float cosA = cosf(rad);
	float sinA = sinf(rad);
	
	float py = *y;
	float pz = *z;
	
	*y = py * cosA - pz * sinA;
	*z = py * sinA + pz * cosA;
}

void transform_point(float inX, float inY, float inZ, float angleX, float angleY, int* px, int* py)
{
	float x = inX;
	float y = inY;
	float z = inZ;

	rotY(&x, &y, &z, angleY);
	rotX(&x, &y, &z, angleX);
	z += 3.0f;

	project(x, y, z, px, py);
}

int main(int argc, char** argv)
{
	_setmode(_fileno(stdout), _O_BINARY);
	
	if (init() < 0) {
		printf("Program must be run with Violet Blue I.\n");
		return -1;
	}
	running = 1;

	float angleX = 45.0f;
	float angleY = 45.0f;

	while (running) {
		cmd_reset();
		pCMD_SETCOLOR(cmdp, 0x00, 0x00, 0x00, 0xFF);
		pCMD_CLEAR(cmdp);
		
		// draw mesh
		int num_triangles = sizeof(tris) / (3 * sizeof(int));
		for (int i = 0; i < num_triangles; ++i) {
			int b0 = (tris[(i*3)]   - 1) * 3;
			int b1 = (tris[(i*3)+1] - 1) * 3;
			int b2 = (tris[(i*3)+2] - 1) * 3;

			int x0, y0, x1, y1, x2, y2;

			transform_point(vertices[b0+0], vertices[b0+1], vertices[b0+2], angleX, angleY, &x0, &y0);
			transform_point(vertices[b1+0], vertices[b1+1], vertices[b1+2], angleX, angleY, &x1, &y1);
			transform_point(vertices[b2+0], vertices[b2+1], vertices[b2+2], angleX, angleY, &x2, &y2);

			pCMD_SETCOLOR(cmdp, 0xFF, 0xFF, 0xFF, 0xFF);
			
			pCMD_SETPOS(cmdp, x0, y0);
			pCMD_DRAWLINE(cmdp, x1, y1);
			
			pCMD_SETPOS(cmdp, x1, y1);
			pCMD_DRAWLINE(cmdp, x2, y2);
			
			pCMD_SETPOS(cmdp, x2, y2);
			pCMD_DRAWLINE(cmdp, x0, y0);
		}
		
		pCMD_SETPOS(cmdp, (areaW/2)-80, areaH-60);
		pCMD_DRAWTEXT(cmdp, 17, "3D Wireframe Cube");
		
		pCMD_SETPOS(cmdp, 10, 10);
		pCMD_DRAWTEXT(cmdp, 18, "Press 'Q' to quit.");
		
		cmd_push();
		
		angleX += 1.0f;
		angleY += 1.0f;
		
		getAreaSize(hwnd, DPIscale, &areaW, &areaH);
		
		if (GetAsyncKeyState('Q') & 0x8000)
			break;
		Sleep(16);
	}
	return 0;
}