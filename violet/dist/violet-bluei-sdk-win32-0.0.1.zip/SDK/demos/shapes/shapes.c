/*

	Violet Blue I SDK demo
	
	Shapes
	AUTHOR Marc-Daniel DALEBA
	DATE 2026-08-11
	DESC
		A program demonstating how Violet interprets
		primitive shapes commands.

*/
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>
#include <fcntl.h>
#include <io.h>
#include <bluei.h>

typedef unsigned char u8;
typedef unsigned int uint;

#define W_WIDTH  600
#define W_HEIGHT 600

#define MODE_MENU 0
#define MODE_LINE 1
#define MODE_RECT 2
#define MODE_ELLI 3
#define MODE_RAND 4
u8 g_exit = 0;
u8 g_mode = MODE_MENU;
u8 g_option = 0;
u8 g_buffer[4000];
u8* g_ptr = g_buffer;
u8 keyq_pressed = 1; // has to be global here
uint g_seed = 123456;

void draw(void);
void update(void);

int main(void)
{
	_setmode(_fileno(stdout), _O_BINARY);
	
	srand(time(NULL));
	g_ptr = g_buffer;
	
	pCMD_ENV(g_ptr);
	fwrite(g_buffer, 1, 1, stdout);
	fflush(stdout);
	Sleep(100);
	uintptr_t hwndValue;
	if (fread(&hwndValue, sizeof(hwndValue), 1, stdin) != 1) {
		return -1;
	}
	HWND hwnd = (HWND)(uintptr_t)hwndValue;

	pCMD_SETWIN(g_ptr, W_WIDTH, W_HEIGHT);
	fwrite(g_buffer, g_ptr-g_buffer, 1, stdout);
	fflush(stdout);
	
	while (!g_exit) {
		update();
		draw();
		Sleep(16);
	}
	
	return 0;
}

const char* menus[] = {
	"Lines\n",
	"Rectangles\n",
	"Ellipses\n",
	"Random\n",
};
int menu_sz[] = { 6, 11, 9, 7 };

void draw_menu(void)
{
	pCMD_SETCOLOR(g_ptr,0,0,0,0xFF);
	pCMD_CLEAR(g_ptr);
	
	pCMD_SETCOLOR(g_ptr, 0xFF, 0xFF, 0xFF, 0xFF);
	pCMD_SETPOS(g_ptr, 10, 10);
	pCMD_DRAWTEXT(g_ptr, 34, "Shapes Example\nPress 'Q' to quit.\n");
	for (int i = 0; i < 4; ++i) {
		pCMD_SETPOS(g_ptr, 10, 70 + 20 * i);
		if (g_option == i)
			pCMD_DRAWTEXT(g_ptr, 2, "> ");
		pCMD_DRAWTEXT(g_ptr, menu_sz[i], menus[i]);
	}
}
void draw_shape(int mode)
{
	pCMD_SETCOLOR(g_ptr,0,0,0,0xFF);
	pCMD_CLEAR(g_ptr);
	
	for (int i = 0; i < 100; ++i) {
		int x = rand()%W_WIDTH;
		int y = rand()%W_HEIGHT;
		int x2 = rand()%W_WIDTH;
		int y2 = rand()%W_HEIGHT;
		int w = rand()%(W_WIDTH/4);
		int h = rand()%(W_HEIGHT/4);
		pCMD_SETCOLOR(
			g_ptr,
			rand()%255,
			rand()%255,
			rand()%255,
			0xFF);
		pCMD_SETPOS(g_ptr, x, y);
		if (mode == MODE_LINE) pCMD_DRAWLINE(g_ptr, x2, y2);
		if (mode == MODE_RECT) pCMD_DRAWRECT(g_ptr, w, h);
		if (mode == MODE_ELLI) pCMD_DRAWELLI(g_ptr, w/2, h/2);
		if (mode == MODE_RAND) {
			int r = rand()%3;
			if (r == 0) pCMD_DRAWLINE(g_ptr, x2, y2);
			if (r == 1) pCMD_DRAWRECT(g_ptr, w, h);
			if (r == 2) pCMD_DRAWELLI(g_ptr, w/2, h/2);
		}
	}
	
	int menu_idx = mode - MODE_LINE;
	pCMD_SETCOLOR(g_ptr, 0xFF, 0xFF, 0xFF, 0xFF);
	pCMD_SETPOS(g_ptr, 10, 10);
	pCMD_DRAWTEXT(g_ptr, menu_sz[menu_idx], menus[menu_idx]);
	pCMD_DRAWTEXT(g_ptr, 22, "Press 'Q' to go back.\n");
}

void draw(void)
{
	g_ptr = g_buffer;
	
	switch (g_mode) {
	case MODE_MENU: draw_menu(); break;
	default:
		draw_shape(g_mode);
		break;
	}
	
	fwrite(g_buffer, g_ptr-g_buffer, 1, stdout);
	fflush(stdout);
}

void update_menu(void)
{
	static u8 keyup_pressed = 1;
	static u8 keydown_pressed = 1;
	static u8 keyenter_pressed = 1;
	
	if (GetAsyncKeyState(VK_UP) & 0x8000) {
		if (!keyup_pressed) {
			g_option -= 1;
			keyup_pressed = 1;
		}
	} else {
		keyup_pressed = 0;
	}
	if (GetAsyncKeyState(VK_DOWN) & 0x8000) {
		if (!keydown_pressed) {
			g_option += 1;
			keydown_pressed = 1;
		}
	} else {
		keydown_pressed = 0;
	}
	
	g_option = (g_option < 0) ? 0 : g_option;
	g_option = (g_option > 3) ? 3 : g_option;
	
	if (GetAsyncKeyState('Q') & 0x8000) {
		if (!keyq_pressed) {
			g_exit = 1;
			return;
		}
	} else {
		keyq_pressed = 0;
	}
	
	if (GetAsyncKeyState(VK_RETURN) & 0x8000) {
		if (!keyenter_pressed) {
			g_mode = MODE_LINE + g_option;
			keyenter_pressed = 1;
		}
	} else {
		keyenter_pressed = 0;
	}
}
void update_shape(void)
{
	if (GetAsyncKeyState('Q') & 0x8000) {
		if (!keyq_pressed) {
			g_mode = MODE_MENU;
			keyq_pressed = 1;
		}
	} else {
		keyq_pressed = 0;
	}
}

void update(void)
{
	switch (g_mode) {
	case MODE_MENU: update_menu(); break;
	default:
		update_shape();
		break;
	}
}