/*

	Violet Blue I SDK demo
	
	Bouncing
	AUTHOR Marc-Daniel DALEBA
	DATE 2026-08-12
	DESC
		A program that shows multiple images bouncing
		inside the window.

*/
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <Windows.h>
#include <fcntl.h>
#include <io.h>
#include <bluei.h>

#define IMG_SIZE 64

int imageLoad(void)
{
	FILE* fp = fopen("icon.raw", "rb");
	if (!fp)
		return -1;
	fseek(fp, 0, SEEK_END);
	size_t len = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	if (len != IMG_SIZE * IMG_SIZE * 4)
		return -1;
	
	char* data = malloc(len);
	if (!data) {
		fclose(fp);
	}
	fread(data, len, 1, fp);
	fclose(fp);
	
	fwrite(data, len, 1, stdout);
	
	free(data);
	return 0;
}

typedef struct ENT {
	int x, y;
	int dx, dy;
} ENT;

#define ENTS_COUNT 80

ENT ents[ENTS_COUNT];

int update_ents(int idx, int areaW, int areaH)
{
	int x = ents[idx].x;
	int y = ents[idx].y;
	int dx = ents[idx].dx;
	int dy = ents[idx].dy;
	int hit = 0;
	
	int nextX = x + dx;
	if (nextX <= 0) {
		x = 0;
		dx = -dx;
		hit = 1;
	} else if (nextX + IMG_SIZE >= areaW) {
		x = areaW - IMG_SIZE;
		dx = -dx;
		hit = 1;
	} else {
		x = nextX;
	}

	// 2. Predict next Y position
	int nextY = y + dy;
	if (nextY <= 0) {
		y = 0;           // Snap directly to top wall
		dy = -dy;
		hit = 1;
	} else if (nextY + IMG_SIZE >= areaH) {
		y = areaH - IMG_SIZE;   // Snap directly to bottom wall
		dy = -dy;
		hit = 1;
	} else {
		y = nextY;
	}
	
	ents[idx].x = x;
	ents[idx].y = y;
	ents[idx].dx = dx;
	ents[idx].dy = dy;
	return hit;
}

void getAreaSize(HWND hwnd, float DPIscale, int* w, int* h)
{
	RECT rc;
	GetClientRect(hwnd, &rc);
	*w = (int)((rc.right - rc.left) * DPIscale);
	*h = (int)((rc.bottom - rc.top) * DPIscale);
}

int randDir(void)
{
	return (rand()%2 == 0) ? -1 : 1;
}

int main(void)
{
	int audioFrames = 0;
	int hit = 0;
	int areaW, areaH;
	
    _setmode(_fileno(stdout), _O_BINARY);
	srand(time(NULL));

	unsigned char cmds[8000];
	unsigned char* cmdp = cmds;

	pCMD_ENV(cmdp);
	fwrite(cmds, 1, 1, stdout);
	fflush(stdout);
	Sleep(100);
	uintptr_t hwndValue;
	if (fread(&hwndValue, sizeof(hwndValue), 1, stdin) != 1) {
		return -1;
	}
	HWND hwnd = (HWND)(uintptr_t)hwndValue;
	
	UINT dpi = GetDpiForWindow(hwnd);
	float scale = (float)dpi / 96.0f;
	
	getAreaSize(hwnd, scale, &areaW, &areaH);
	
	for (int i = 0; i < ENTS_COUNT; ++i) {
		ents[i].x = rand()%(areaW-IMG_SIZE);
		ents[i].y = rand()%(areaH-IMG_SIZE);
		ents[i].dx = randDir() * ((rand()%5)+5);
		ents[i].dy = randDir() * ((rand()%5)+5);
	}
	
	cmdp = cmds;
	pPut8(cmdp, 0x05);
	pPut16(cmdp, IMG_SIZE);
	pPut16(cmdp, IMG_SIZE);
	fwrite(cmds, cmdp-cmds, 1, stdout);
	if (imageLoad() < 0)
		return 0;
	fflush(stdout);
	
	for (;;) {
		cmdp = cmds;
		pCMD_SETCOLOR(cmdp, 0x00, 0x00, 0x00, 0xFF);
		pCMD_CLEAR(cmdp);
		
		for (int i = 0; i < ENTS_COUNT; ++i) {
			pCMD_SETPOS(cmdp, ents[i].x, ents[i].y);
			pCMD_DRAWBITM(cmdp);
		}
		
		hit = 0;
		getAreaSize(hwnd, scale, &areaW, &areaH);
		for (int i = 0; i < ENTS_COUNT; ++i) {
			hit += update_ents(i, areaW, areaH);
		}
		
		// 3. Audio trigger logic
		if (hit && audioFrames < 0) {
			pCMD_SETAUDIO(cmdp, 0, WAVE_TRIANGLE, 440); 
			pCMD_CHVOLUME(cmdp, 0, 80);
			audioFrames = 5;
		}
		
		if (audioFrames >= 0) {
			audioFrames--;
		}
		
		if (audioFrames == 0) {
			pCMD_SETAUDIO(cmdp, 0, WAVE_NONE, 440); 
		}
		
		pCMD_SETCOLOR(cmdp, 0xFF, 0xFF, 0xFF, 0xFF);
		pCMD_SETPOS(cmdp, 0, 0);
		pCMD_DRAWTEXT(cmdp, 32, "Bouncing Logo\nPress 'Q' to exit.");
		
		fwrite(cmds, cmdp-cmds, 1, stdout);
		fflush(stdout);
		
		if (GetAsyncKeyState('Q') & 0x8000)
			break;
		Sleep(16);
	}
    return 0;
}