========================================================================
PowerRenamer v1.0.1.3
Fast and easy batch file renaming for Windows.
========================================================================

Thank you for downloading PowerRenamer!

PowerRenamer is a lightweight batch file renamer designed for instant 
pattern application, live real-time previewing, and automatic collision 
prevention.


QUICK START GUIDE
------------------------------------------------------------------------
1. Launch PowerRenamer.exe (No installation required).
2. Drag and drop your files directly into the file list.
3. Type your desired pattern into the Pattern box (e.g., $filename$_$index$.$ext$).
   - Tip: Click the "Puzzle Piece" icon to open the token menu and insert tokens instantly.
4. Verify the generated names in the New Name column.
5. Click "Apply" to update the preview in the application.
6. Click "Run" to execute the changes on disk.


AVAILABLE PATTERN TOKENS
------------------------------------------------------------------------
  $index$     - Appends sequential numbering (1, 2, 3...)
  $index[n]$  - Appends zero-padded sequential numbering (e.g., $index[3]$ -> 001)
  $filename$  - Preserves the original filename (without extension)
  $ext$       - Keeps the original file extension


KEY FEATURES
------------------------------------------------------------------------
* Token-based Renaming: Use pattern tokens to make renaming dynamic.
* Fast Live Preview: Updates instantaneously as you type.
* Anti-Collision Indexing: Automatically increments duplicate filenames 
  to prevent accidental data overwrites.
* 100% Portable: No registry bloat, installers, or dependencies.


SYSTEM REQUIREMENTS
------------------------------------------------------------------------
* Windows 7 / 8 / 10 / 11 (64-bit)
* No additional frameworks required


SUPPORT & MAINTENANCE
------------------------------------------------------------------------
PowerRenamer is actively maintained. If you encounter any bugs, have 
feature requests, or need assistance, please contact direct support:

  Email: contact@mdaleba.com
  Subject: PowerRenamer Support


HOMEPAGE & LICENSING
------------------------------------------------------------------------
PowerRenamer is free for personal, non-commercial use. 

For commercial licensing, updates, and documentation, visit our homepage:
https://mdaleba.com/powerrenamer/

========================================================================
Copyright (c) 2026 Marc-Daniel DALEBA. All rights reserved.